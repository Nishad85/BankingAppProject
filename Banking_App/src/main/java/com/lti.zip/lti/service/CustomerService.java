package com.lti.service;

import com.lti.entity.Customer;

public interface CustomerService {


	public Customer addCustomer(Customer c, long userid);

	public Customer viewDetails(long customerid);
	
}
