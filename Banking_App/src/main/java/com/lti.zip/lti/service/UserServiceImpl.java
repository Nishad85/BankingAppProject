package com.lti.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.UserRepository;
import com.lti.entity.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository urepo;
	
	@Override
	@Transactional
	public User createUser(User data) {
		return urepo.save(data);
	}

	@Override
	public User viewDetails(long userid) {
		Optional<User> ufind = urepo.findById(userid);
	    User ugot= null;
	    if(ufind.isPresent()) {
	    	ugot=ufind.get();
	    }
	    return ugot;
	}
	
	
	
	
	
}
