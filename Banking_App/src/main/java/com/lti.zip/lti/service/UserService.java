package com.lti.service;


import com.lti.entity.User;

public interface UserService {

	public User createUser(User data);
	
	public User viewDetails(long userid);
}
