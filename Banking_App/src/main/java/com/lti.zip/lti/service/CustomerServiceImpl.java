package com.lti.service;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.CustomerRepository;
import com.lti.dao.UserRepository;
import com.lti.entity.Customer;
import com.lti.entity.User;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private UserRepository urepo;
	
	@Autowired
	private CustomerRepository crepo;
	
	

	@Override
	@Transactional 
	public Customer addCustomer(Customer c, long userid) {
		
		Optional<User> ufind= urepo.findById(userid);
		User ugot=null;
		Random random = new Random();
		int min = 10000000;
		int max = 99999999;
		int accountNumber = min+random.nextInt(max);
		
		if(ufind.isPresent()) {
			ugot=ufind.get();
			c.setUser(ugot);
			c.setAccno(accountNumber);
		}

		return crepo.save(c);
	}


	@Override
	public Customer viewDetails(long customerid) {
		Optional<Customer> cust = crepo.findById(customerid);
		Customer custfind = null;
		if(cust.isPresent()) {
			custfind=cust.get();
			return custfind;
		}
		return custfind;
	}
	
}
