package com.lti.exception;

public class NoAdminFoundException extends Exception{

	public NoAdminFoundException(String msg) {
		super(msg);
	}
}
