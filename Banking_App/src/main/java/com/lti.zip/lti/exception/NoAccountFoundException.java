package com.lti.exception;

public class NoAccountFoundException extends Exception{
	
	public NoAccountFoundException(String msg){
		super(msg);
	}
}
