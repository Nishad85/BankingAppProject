package com.lti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.lti.entity.User;
import com.lti.exception.NoAdminFoundException;
import com.lti.service.UserService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	private UserService us;
	
	@PostMapping("/createuser")
	public User createUser(@RequestBody User u) {
		return us.createUser(u);
	}
	
	@GetMapping("/finduser/{userid}")
	public User getUser(@PathVariable("userid") long userid) throws NoAdminFoundException {
		return us.viewDetails(userid);
	}
	
}
